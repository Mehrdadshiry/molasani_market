import 'dotenv/config'
const token=process.env.BOT_TOKEN
const webapp=process.env.WEBAPP_URL
if(!token){console.error('BOT_TOKEN را در فایل .env تنظیم کنید.');process.exit(1)}
if(!webapp || !webapp.startsWith('https://')){console.error('WEBAPP_URL باید آدرس HTTPS مینی‌اپ باشد.');process.exit(1)}
const api=`https://api.telegram.org/bot${token}`
async function call(method,body={}){
  const r=await fetch(`${api}/${method}`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)})
  const d=await r.json()
  if(!d.ok) throw new Error(d.description||'Telegram API error')
  return d.result
}
async function main(){
  let offset=0
  console.log('ربات فروشگاه فعال شد.')
  while(true){
    try{
      const updates=await call('getUpdates',{offset,timeout:30,allowed_updates:['message']})
      for(const u of updates){
        offset=u.update_id+1
        const m=u.message
        if(!m?.chat?.id)continue
        const text=m.text||''
        if(text==='/start' || text.startsWith('/start ')){
          await call('sendMessage',{
            chat_id:m.chat.id,
            text:'به فروشگاه آنلاین خوش آمدید. برای مشاهده کالاها و ثبت سفارش، دکمه زیر را بزنید.',
            reply_markup:{keyboard:[[{text:'🛒 ورود به فروشگاه',web_app:{url:webapp}}]],resize_keyboard:true}
          })
        } else {
          await call('sendMessage',{chat_id:m.chat.id,text:'برای باز کردن فروشگاه، دستور /start را بفرستید.'})
        }
      }
    }catch(e){console.error(e.message);await new Promise(r=>setTimeout(r,2500))}
  }
}
main()
