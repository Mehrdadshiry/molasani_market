import fs from 'node:fs'
const path = './server/data.json'
if (!fs.existsSync(path)) fs.writeFileSync(path, JSON.stringify({products:[],orders:[],nextProductId:1,nextOrderId:1},null,2))
export function readDB(){return JSON.parse(fs.readFileSync(path,'utf8'))}
export function writeDB(data){fs.writeFileSync(path,JSON.stringify(data,null,2))}
