import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import multer from 'multer'
import XLSX from 'xlsx'
import {readDB,writeDB} from './db.js'
import {createOnlinePayment} from './payment.js'

const app=express(), upload=multer({storage:multer.memoryStorage(),limits:{fileSize:5*1024*1024}})
app.use(cors()); app.use(express.json())
const admin=(req,res,next)=>{if(!process.env.ADMIN_KEY || req.header('x-admin-key')!==process.env.ADMIN_KEY)return res.status(401).json({error:'دسترسی مدیریت مجاز نیست'});next()}
app.get('/api/health',(req,res)=>res.json({ok:true}))
app.get('/api/products',(req,res)=>res.json(readDB().products.filter(p=>p.active)))
app.post('/api/orders',async(req,res)=>{
  const {customer,items}=req.body||{}
  if(!customer?.name||!customer?.phone||!Array.isArray(items)||!items.length)return res.status(400).json({error:'اطلاعات سفارش ناقص است'})
  const db=readDB(), lines=[]
  for(const item of items){
    const p=db.products.find(x=>x.id===Number(item.productId)&&x.active)
    const qty=Number(item.quantity)
    if(!p||!Number.isInteger(qty)||qty<1||qty>p.stock)return res.status(400).json({error:'کالا ناموجود است یا تعداد معتبر نیست'})
    lines.push({productId:p.id,name:p.name,price:p.price,quantity:qty,lineTotal:p.price*qty})
  }
  const total=lines.reduce((s,x)=>s+x.lineTotal,0)
  const order={id:db.nextOrderId++,customer_name:String(customer.name).slice(0,120),phone:String(customer.phone).slice(0,30),address:String(customer.address||'').slice(0,500),payment:customer.payment==='online'?'online':'cod',delivery:customer.delivery==='pickup'?'pickup':'delivery',items:lines,total,status:'new',createdAt:new Date().toISOString(),telegramUserId:customer.telegramUserId||null}
  for(const line of lines){const p=db.products.find(x=>x.id===line.productId);p.stock-=line.quantity}
  db.orders.unshift(order);writeDB(db)
  let payment=null
  if(order.payment==='online') payment=await createOnlinePayment(order)
  res.status(201).json({order,payment})
})
app.get('/api/admin/orders',admin,(req,res)=>res.json(readDB().orders))
app.patch('/api/admin/orders/:id',admin,(req,res)=>{
  const db=readDB(),o=db.orders.find(x=>x.id===Number(req.params.id))
  if(!o)return res.status(404).json({error:'سفارش پیدا نشد'})
  const allowed=['new','preparing','sent','completed','cancelled']
  if(!allowed.includes(req.body.status))return res.status(400).json({error:'وضعیت نامعتبر'})
  o.status=req.body.status;writeDB(db);res.json(o)
})
app.post('/api/admin/products/import',admin,upload.single('file'),(req,res)=>{
  if(!req.file)return res.status(400).json({error:'فایل ارسال نشده است'})
  try{
    const wb=XLSX.read(req.file.buffer,{type:'buffer'}),sheet=wb.Sheets[wb.SheetNames[0]]
    const rows=XLSX.utils.sheet_to_json(sheet,{defval:''}),db=readDB()
    let count=0
    for(const row of rows){
      const name=String(row.name||row['نام کالا']||row['نام']||'').trim()
      if(!name)continue
      const sku=String(row.sku||row['کد کالا']||'').trim()
      const price=Math.max(0,Math.round(Number(row.price||row['قیمت']||0)))
      const stock=Math.max(0,Math.floor(Number(row.stock||row['موجودی']||0)))
      const product={sku,name,category:String(row.category||row['دسته‌بندی']||'متفرقه'),price,stock,unit:String(row.unit||row['واحد']||'عدد'),imageUrl:String(row.imageUrl||row['آدرس عکس']||''),active:!['false','0','خیر'].includes(String(row.active).toLowerCase())}
      const old=sku?db.products.find(p=>p.sku===sku):null
      if(old)Object.assign(old,product)
      else db.products.push({id:db.nextProductId++,...product})
      count++
    }
    writeDB(db);res.json({message:`${count} کالا وارد یا به‌روزرسانی شد.`})
  }catch(e){res.status(400).json({error:'خواندن فایل ناموفق بود: '+e.message})}
})
app.listen(Number(process.env.PORT||3001),()=>console.log('API listening on '+(process.env.PORT||3001)))
