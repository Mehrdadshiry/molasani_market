import React, { useEffect, useMemo, useState } from 'react'

const API = import.meta.env.VITE_API_URL || 'http://localhost:3001'
const money = n => new Intl.NumberFormat('fa-IR').format(n || 0) + ' تومان'

function telegramUser() {
  const tg = window.Telegram?.WebApp
  try { tg?.ready(); tg?.expand() } catch {}
  return tg?.initDataUnsafe?.user || null
}

export default function App() {
  const [products, setProducts] = useState([])
  const [cart, setCart] = useState({})
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('همه')
  const [page, setPage] = useState('shop')
  const [orders, setOrders] = useState([])
  const [form, setForm] = useState({name:'', phone:'', address:'', payment:'cod', delivery:'delivery'})
  const [message, setMessage] = useState('')
  const [busy, setBusy] = useState(false)
  const user = telegramUser()

  async function load() {
    try {
      const r = await fetch(`${API}/api/products`)
      setProducts(await r.json())
    } catch { setMessage('ارتباط با سرور برقرار نشد. ابتدا سرور پروژه را اجرا کنید.') }
  }
  useEffect(() => { load() }, [])
  const categories = ['همه', ...new Set(products.map(p => p.category).filter(Boolean))]
  const shown = useMemo(() => products.filter(p =>
    p.active && (category === 'همه' || p.category === category) &&
    p.name.toLowerCase().includes(search.toLowerCase())
  ), [products, category, search])
  const cartItems = Object.entries(cart).map(([id, qty]) => {
    const p = products.find(x => String(x.id) === id)
    return p ? {...p, qty} : null
  }).filter(Boolean)
  const total = cartItems.reduce((s,p) => s + p.price*p.qty, 0)
  function add(p, delta=1) {
    setCart(old => {
      const next = {...old}, qty = (next[p.id] || 0) + delta
      if (qty <= 0) delete next[p.id]
      else if (qty <= p.stock) next[p.id] = qty
      return next
    })
  }
  async function submitOrder(e) {
    e.preventDefault()
    if (!cartItems.length) return
    if (!form.name || !form.phone || (form.delivery === 'delivery' && !form.address)) {
      setMessage('نام، شماره تماس و در صورت ارسال، نشانی را وارد کنید.'); return
    }
    setBusy(true); setMessage('')
    try {
      const r = await fetch(`${API}/api/orders`, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body:JSON.stringify({
          customer:{...form, telegramUserId:user?.id || null},
          items:cartItems.map(p=>({productId:p.id, quantity:p.qty}))
        })
      })
      const data = await r.json()
      if (!r.ok) throw new Error(data.error || 'ثبت سفارش ناموفق بود')
      setMessage(`سفارش شما با شماره ${data.order.id} ثبت شد. مبلغ: ${money(data.order.total)}${form.payment==='online' ? ' — برای پرداخت آنلاین، درگاه باید توسط مدیر فعال شود.' : ''}`)
      setCart({})
      setPage('shop')
    } catch(err) { setMessage(err.message) }
    finally { setBusy(false) }
  }
  async function loadOrders() {
    const key = prompt('کلید مدیریت را وارد کنید')
    if (!key) return
    const r = await fetch(`${API}/api/admin/orders`, {headers:{'x-admin-key':key}})
    if (!r.ok) { setMessage('کلید مدیریت نامعتبر است'); return }
    setOrders(await r.json()); sessionStorage.setItem('adminKey',key); setPage('admin')
  }
  async function importExcel(e) {
    const file=e.target.files?.[0]; if(!file) return
    const key=sessionStorage.getItem('adminKey') || prompt('کلید مدیریت را وارد کنید')
    if(!key) return
    const fd=new FormData(); fd.append('file',file)
    const r=await fetch(`${API}/api/admin/products/import`,{method:'POST',headers:{'x-admin-key':key},body:fd})
    const d=await r.json(); setMessage(d.message || d.error || 'پایان ورود فایل'); load()
  }
  async function updateStatus(id,status) {
    const key=sessionStorage.getItem('adminKey')
    const r=await fetch(`${API}/api/admin/orders/${id}`,{method:'PATCH',headers:{'Content-Type':'application/json','x-admin-key':key},body:JSON.stringify({status})})
    if(r.ok) setOrders(await (await fetch(`${API}/api/admin/orders`,{headers:{'x-admin-key':key}})).json())
  }

  return <div className="app">
    <header><div className="brand">🛒 سوپرمارکت آنلاین</div><button className="ghost" onClick={()=>setPage('cart')}>سبد خرید ({cartItems.length})</button></header>
    <nav><button className={page==='shop'?'selected':''} onClick={()=>setPage('shop')}>فروشگاه</button><button className={page==='cart'?'selected':''} onClick={()=>setPage('cart')}>سبد خرید</button><button onClick={loadOrders}>مدیریت</button></nav>
    {message && <div className="notice">{message}</div>}
    {page==='shop' && <>
      <input className="search" placeholder="جست‌وجوی کالا..." value={search} onChange={e=>setSearch(e.target.value)}/>
      <div className="chips">{categories.map(c=><button key={c} className={category===c?'active':''} onClick={()=>setCategory(c)}>{c}</button>)}</div>
      <div className="grid">{shown.map(p=><article className="product" key={p.id}>
        {p.imageUrl ? <img src={p.imageUrl} /> : <div className="placeholder">🛍️</div>}
        <b>{p.name}</b><small>{p.category || 'متفرقه'} · {p.unit || 'عدد'}</small>
        <strong>{money(p.price)}</strong><small>موجودی: {p.stock}</small>
        <button disabled={p.stock<1} onClick={()=>add(p)}>افزودن به سبد</button>
      </article>)}</div>
    </>}
    {page==='cart' && <section className="panel">
      <h2>سبد خرید</h2>
      {!cartItems.length && <p>سبد خرید خالی است.</p>}
      {cartItems.map(p=><div className="cartrow" key={p.id}><div><b>{p.name}</b><small>{money(p.price)} × {p.qty}</small></div><div className="qty"><button onClick={()=>add(p,-1)}>−</button><b>{p.qty}</b><button onClick={()=>add(p,1)}>+</button></div></div>)}
      <h3>جمع کل: {money(total)}</h3>
      {!!cartItems.length && <form onSubmit={submitOrder}>
        <h3>اطلاعات سفارش</h3>
        <input required placeholder="نام و نام خانوادگی" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>
        <input required placeholder="شماره تماس" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/>
        <label>روش تحویل</label><select value={form.delivery} onChange={e=>setForm({...form,delivery:e.target.value})}><option value="delivery">ارسال با پیک</option><option value="pickup">تحویل حضوری</option></select>
        {form.delivery==='delivery' && <textarea required placeholder="نشانی کامل" value={form.address} onChange={e=>setForm({...form,address:e.target.value})}/>}
        <label>روش پرداخت</label><select value={form.payment} onChange={e=>setForm({...form,payment:e.target.value})}><option value="cod">پرداخت هنگام تحویل</option><option value="online">پرداخت اینترنتی (پس از فعال‌سازی درگاه)</option></select>
        <button disabled={busy} type="submit">{busy?'در حال ثبت...':'ثبت سفارش'}</button>
      </form>}
    </section>}
    {page==='admin' && <section className="panel">
      <h2>مدیریت سفارش‌ها و کالاها</h2>
      <p>ورود کالا از فایل اکسل (.xlsx یا .csv)</p><input type="file" accept=".xlsx,.xls,.csv" onChange={importExcel}/>
      <h3>سفارش‌ها</h3>
      {orders.map(o=><div className="order" key={o.id}><b>#{o.id} — {o.customer_name}</b><span>{money(o.total)}</span><small>{o.phone} · {o.delivery==='pickup'?'تحویل حضوری':'ارسال'} · {o.payment==='online'?'آنلاین':'هنگام تحویل'}</small><select value={o.status} onChange={e=>updateStatus(o.id,e.target.value)}><option value="new">جدید</option><option value="preparing">در حال آماده‌سازی</option><option value="sent">ارسال‌شده</option><option value="completed">تحویل‌شده</option><option value="cancelled">لغوشده</option></select></div>)}
    </section>}
    <footer>فروشگاه نمونه · قیمت‌ها به تومان</footer>
  </div>
}
